# サンプルTRPG・セッション開始ガイド

## このパックの中身

| ファイル | 役割 |
|---|---|
| AI_TRPG_OS_Core_v1_34_EN.json | OS本体 |
| NoiseLog_AI_TRPG_OS_v2_7_EN.json | ミスパターン蓄積 |
| App_サンプルTRPG_v1_1.json | ルール（d20） |
| Scenario_サンプルTRPG_v2_1.json | シナリオ本体（GM専用） |
| StartPrompt_サンプルTRPG_v1_0.json | 起動の指示書 |

---

## 初回セッションの始め方

1. 新規チャットを開く

2. 以下の4ファイルをアップロードする
   - AI_TRPG_OS_Core_v1_34_EN.json
   - NoiseLog_AI_TRPG_OS_v2_7_EN.json
   - App_サンプルTRPG_v1_1.json
   - Scenario_サンプルTRPG_v2_1.json

   （Claudeのプロジェクト機能を使う場合は、この4ファイルをプロジェクトに入れておけば毎回アップロード不要）

3. 続けて StartPrompt_サンプルTRPG_v1_0.json をアップロードして送信する

4. AIが「integrity OK」と出力したらセッション開始

---

## 2回目以降の始め方

前回のセッション終了時にAIが出力した3ファイルをアップロードするだけ。

- Session_Start_S[番号].json
- PlayLog_帝都.json
- [PC名]_CharacterSheet.json

StartPromptは不要。Session_Startが起動の役割を引き継ぐ。

---

## ダイスルール

- PCの判定：プレイヤーがダイスを振り、結果をAIに伝える
- 敵・NPCの判定：AIが振る

---

## セッションの終わり方

「セッション終了」と入力すると、AIが次回用の3ファイル（Session_Start・PlayLog・CharacterSheet）を出力する。次回はそれをアップロードして始める。

